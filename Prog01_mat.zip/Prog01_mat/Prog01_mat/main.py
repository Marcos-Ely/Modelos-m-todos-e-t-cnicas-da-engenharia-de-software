from calculadora import *

if __name__ == "__main__":

    root.mainloop()