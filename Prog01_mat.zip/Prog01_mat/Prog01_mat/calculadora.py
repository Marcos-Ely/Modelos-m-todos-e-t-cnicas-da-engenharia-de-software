import tkinter as tk

def press(key):
    current = display.get()
    display.delete(0, tk.END)
    display.insert(tk.END, current + key)

def calculate():
    try:
        result = eval(display.get())  # Avalia a expressão no display
        display.delete(0, tk.END)
        display.insert(tk.END, result)
    except Exception as e:
        display.delete(0, tk.END)
        display.insert(tk.END, "Erro")

def clear():
    display.delete(0, tk.END)

root = tk.Tk()
root.title("Calculadora")

display = tk.Entry(root, font=("Arial", 20), borderwidth=2, relief="solid", width=15, justify="right")
display.grid(row=0, column=0, columnspan=4)

buttons = [
    '7', '8', '9', '/',
    '4', '5', '6', '*',
    '1', '2', '3', '-',
    'C', '0', '=', '+'
]

row = 1
col = 0
for button in buttons:
    if button == "=":
        tk.Button(root, text=button, font=("Arial", 20), width=5, height=2, command=calculate).grid(row=row, column=col)
    elif button == "C":
        tk.Button(root, text=button, font=("Arial", 20), width=5, height=2, command=clear).grid(row=row, column=col)
    else:
        tk.Button(root, text=button, font=("Arial", 20), width=5, height=2, command=lambda key=button: press(key)).grid(
            row=row, column=col)

    col += 1
    if col > 3:
        col = 0
        row += 1

root.mainloop()