
class Biblioteca:
    def __init__(self):
        self.livros = []
        self.clientes = []

    def adicionar_livro(self, livro):
        self.livros.append(livro)
        print(f"Livro '{livro.titulo}' adicionado à biblioteca.")

    def adicionar_cliente(self, cliente):
        self.clientes.append(cliente)
        print(f"Cliente {cliente.nome} adicionado à biblioteca.")

    def listar_livros(self):
        if self.livros:
            print("Livros disponíveis na biblioteca:")
            for livro in self.livros:
                status = "Disponível" if livro.disponivel else "Indisponível"
                print(f"{livro} - Status: {status}")
        else:
            print("Nenhum livro disponível.")

    def listar_clientes(self):
        if self.clientes:
            print("Clientes da biblioteca:")
            for cliente in self.clientes:
                print(cliente)
        else:
            print("Nenhum cliente cadastrado.")