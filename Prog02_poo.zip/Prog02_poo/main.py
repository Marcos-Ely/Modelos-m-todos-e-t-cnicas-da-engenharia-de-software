from biblioteca import Biblioteca
from cliente import Cliente
from livro import Livro

biblioteca = Biblioteca()

livro1 = Livro("Dom Casmurro", "Machado de Assis", 1)
livro2 = Livro("O Primo Basílio", "José de Alencar", 2)
livro3 = Livro("A Moreninha", "Joaquim Manuel de Macedo", 3)

biblioteca.adicionar_livro(livro1)
biblioteca.adicionar_livro(livro2)
biblioteca.adicionar_livro(livro3)

cliente1 = Cliente("Maria Silva", 101)
cliente2 = Cliente("João Santos", 102)

biblioteca.adicionar_cliente(cliente1)
biblioteca.adicionar_cliente(cliente2)

biblioteca.listar_livros()
biblioteca.listar_clientes()

cliente1.emprestar_livro(livro1)
cliente2.emprestar_livro(livro1)
cliente2.emprestar_livro(livro2)


cliente1.devolver_livro(livro1)
cliente2.devolver_livro(livro2)