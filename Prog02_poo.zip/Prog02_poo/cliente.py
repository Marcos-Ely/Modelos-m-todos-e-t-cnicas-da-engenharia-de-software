class Cliente:
    def __init__(self, nome, id_cliente):
        self.nome = nome
        self.id_cliente = id_cliente
        self.livros_emprestados = []  # Lista de livros emprestados pelo cliente

    def emprestar_livro(self, livro):
        if livro.disponivel:
            livro.emprestar()
            self.livros_emprestados.append(livro)
        else:
            print(f"Não foi possível emprestar '{livro.titulo}' para {self.nome}.")

    def devolver_livro(self, livro):
        if livro in self.livros_emprestados:
            livro.devolver()
            self.livros_emprestados.remove(livro)
        else:
            print(f"{self.nome} não possui o livro '{livro.titulo}' para devolver.")

    def __str__(self):
        return f"{self.nome} (ID: {self.id_cliente})"